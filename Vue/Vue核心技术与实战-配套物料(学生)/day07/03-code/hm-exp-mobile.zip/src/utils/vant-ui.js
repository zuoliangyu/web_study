// 按需导入：将需要的vant组件，逐一导入
import {
  Grid,
  GridItem,
  CellGroup, Icon, List, Cell, Toast, NavBar, Form, Field, Button, Rate, Tabbar, TabbarItem
} from 'vant'
import Vue from 'vue'
Vue.use(Grid)
Vue.use(GridItem)
Vue.use(CellGroup)
Vue.use(Icon)
Vue.use(List)
Vue.use(Cell)
Vue.use(Toast)
Vue.use(NavBar)
Vue.use(Form)
Vue.use(Field)
Vue.use(Tabbar)
Vue.use(TabbarItem)
Vue.use(Button)
Vue.use(Rate)
